const mongoose = require('mongoose');

const model = mongoose.model('luppux-guard-punish', mongoose.Schema({
    serverId: String,
    type: String,
    action: String
}));

module.exports = model;