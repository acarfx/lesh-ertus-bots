const { Schema, model } = require("mongoose");


const webGuildStatistics = new Schema({
    guildId: { type: String, default: "" },
    guildMemberCount: { type: Number, default: 0 },
    guildBoostCount: { type: Number, default: 0 },
    guildTagCount: { type: Number, default: 0 },
    guildVoiceCount: { type: Number, default: 0 },
    latestUpdate: { type: Date, default: Date.now() },
});

module.exports = model("webGuildStatistics", webGuildStatistics);