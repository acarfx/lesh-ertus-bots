const { Schema, model } = require("mongoose");


const userSchema = new Schema({
    customerId: { type: String, default: null },
    currentPlan: { type: String, default: null },
    userId: { type: String, default: null },
    password: { type: String, default: null },
    email: { type: String, default: null },
    guildId: { type: String, default: null },
    permission: { type: String, default: null },
    phone: { type: String, default: null },
    isTwoFactorEnabled: { type: Boolean, default: false },
    twoFactorSecret: { type: String, default: null },
    twoFactorRecovery: { type: String, default: null },
});

module.exports = model("users", userSchema);


/**
 * {
 * "_id":{"$oid":"66798f9461e7f9e888bf2dd0"},
 * "unique_id":"587564522009788426",
 * "createdAt":"",
 * "email":"crane@celx.shop",
 * "guildId":"1165001601275146301",
 * "is2FAEnabled":false,
 * "password":"12345",
 * "passwordConf":"12345",
 * "permissions":"Admin",
 * "username":"crane"
 * }
 * 
 * {
    "_id":{"$oid":"66798f9461e7f9e888bf2dd0"},
    "customerId": "",
    "currentPlan": "Bronze",
    "userId": "587564522009788426",
    "guildId":"1165001601275146301",
    "password":"12345",
    "email": "crane@celx.store",
    "permission":"Admin",
    "phone": "905555555555",
    "isTwoFactorEnabled": false,
    "twoFactorSecret": "",
    "twoFactorRecovery": ""
 * }
 */