const mongoose = require('mongoose');

const model = mongoose.Schema({
    userId: { type: String, default: "" },
    releventField: { type: String, default: "Software" },
    website: { type: String, default: "" },
    exprerience: { type: Array, default: [] },
})

module.exports = mongoose.model('team', model);