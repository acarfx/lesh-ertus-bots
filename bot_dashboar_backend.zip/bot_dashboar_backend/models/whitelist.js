const mongoose = require('mongoose');

const model = mongoose.Schema({
    guildID: String,
    user: String,
    type: String,
    totalLimit: Number,
    maker: { type: String, default: "" }
})

module.exports = mongoose.model('whitelist', model);