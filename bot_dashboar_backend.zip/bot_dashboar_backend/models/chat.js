const mongoose = require('mongoose');

const model = mongoose.model('support-chat', mongoose.Schema({
    userId: String,
    supportId: String,
    title: String,
    messages: Array,
    createdAt: { type: Date, default: Date.now() }
}));

module.exports = model;