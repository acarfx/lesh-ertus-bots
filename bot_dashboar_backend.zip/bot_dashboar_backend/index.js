const express = require("express");
const app = express();
const path = require("path");
const mongoose = require("mongoose");
const config = require("./config.json")
const cors = require("cors");
const { Client, GatewayIntentBits, Partials, Events, AuditLogEvent, EmbedBuilder, Colors } = require("discord.js");
const { GoogleGenerativeAI } = require("@google/generative-ai")

const PORT = 3001;

const client = new Client({
    intents: Object.keys(GatewayIntentBits),
    partials: Object.keys(Partials)
});


client.on(Events.ClientReady, async () => {
    console.log("Bot başarıyla başlatıldı");
});

const login = require("./routes/login");
const sessions = require("./models/sessions");
const user = require("./models/user");
const setup = require("./models/setup");
const guard = require("./models/guard-settings");
const gEkle = require("./models/gorev-ekle");
const gpoint = require("./models/gorev-puan");
const whitelist = require("./models/whitelist");
const webGuildStatistics = require("./models/guild-statistics");
const chat = require("./models/chat");
const team = require("./models/team");
const https = require('https');

const agent = new https.Agent({
    rejectUnauthorized: false, // Güvenlik kontrolünü kapatır
});

https.get('https://self-signed.badssl.com/', { agent }, (res) => {
    console.log('Status Code:', res.statusCode);
});
app.set('view engine', 'ejs');
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

/* enable cors */
app.use(
    cors({
        origin: "*",
        methods: ["GET", "POST"],
        allowedHeaders: ["Content-Type", "Authorization"]
    })
);


mongoose.connect(config.mongoURL, {
    useNewUrlParser: true,
    useUnifiedTopology: true
}).then(() => {
    console.log("MongoDB'ye bağlanıldı");
}).catch((err) => {
    console.log("MongoDB'ye bağlanırken hata oluştu: " + err);
});

app.use(express.json());
app.use(express.urlencoded({ extended: false }));


async function checkSession(res, token) {
    if (!token) {
        res.status(404).json({ success: false, message: "Token bulunamadı", matter: "session" });
        return false;
    }

    token = JSON.parse(token);
    const session = await sessions.findOne({ token });

    if (!session) {
        res.status(404).json({ success: false, message: "Oturum bulunamadı, tekrar giriş yapın", matter: "session" });
        return false;
    }
    if (Date.now() >= session.expires) {
        await sessions.findOneAndDelete({ token })
            .catch(e => {
                console.log(e);
                res.status(500).json({ success: false, message: "Sunucu hatası" });
            });
        res.status(401).json({ success: false, message: "Oturum süresi doldu, tekrar giriş yapın" });
        return session ? session : false;
    }
    return session
}

app.get('/token-validation', async (req, res) => {
    const { authorization } = req.headers;
    const token = authorization.split(" ")[1];
    const session = await checkSession(res, token);
    if (!session) return;
    const userData = await user.findOne({ userId: session.userId });
    if (!userData) return res.status(404).json({ success: false, message: "Kullanıcı bulunamadı." });
    return res.status(200).json({ success: true, message: "Token geçerli", data: userData });
});


app.get('/admin', async (req, res) => {
    const { authorization } = req.headers;
    const token = authorization.split(" ")[1];

    const session = await checkSession(res, token);
    if (!session) return;
    let userData = await user.findOne({ userId: session.userId });
    if (!userData) return res.status(404).json({ success: false, message: "Kullanıcı bulunamadı." });
    if (userData.permission != "Admin") return res.status(404).json({ success: false, message: "Kullanıcı bulunamadı." });

    const guilds = client.guilds.cache;
    res.status(200).json({ success: true, guilds });
});


app.get('/team', async (req, res) => {
    const { authorization } = req.headers;
    const token = authorization.split(" ")[1];

    const session = await checkSession(res, token);
    if (!session) return;
    let userData = await user.findOne({ userId: session.userId });
    if (!userData) return res.status(404).json({ success: false, message: "Kullanıcı bulunamadı." });
    if (userData.permission != "Admin") return res.status(404).json({ success: false, message: "Kullanıcı bulunamadı." });
    let teamData = await team.find();
    const guildData = client.users.cache;
    if (!teamData) return res.status(404).json({ success: false, message: "Takım bulunamadı." });


    const teamNewData = [
    ]


    teamData.map((p, i) => {
        console.log("---------------------------------------------------------------------------------------------")
        teamNewData.push(
            {
                userId: p.userId,
                releventField: p.relevantField,
                website: p.website,
                experience: p.exprerience,
                user: guildData.find(x => x.id == p.userId)
            }
        )
    });

    console.log(teamNewData)


    res.status(200).json({
        success: true,
        team: teamNewData
    })
});

app.post('/team', async (req, res) => {
    const { authorization } = req.headers;
    const token = authorization.split(" ")[1];
    const {userId, relevantField, website, selectedOptions} = req.body;

    const session = await checkSession(res, token);
    if (!session) return;
    let userData = await user.findOne({ userId: session.userId });
    if (!userData) return res.status(404).json({ success: false, message: "Kullanıcı bulunamadı." });
    if (userData.permission != "Admin") return res.status(404).json({ success: false, message: "Kullanıcı bulunamadı." });
    let teamData = await team.find();
    if (!teamData) {
        const newTeam = new team({
            userId,
            releventField: relevantField,
            website,
            exprerience: selectedOptions
        })

        newTeam.save()
        .then(x => {
            res.status(200).json({
                success: true,
                team: x
            })
        }).catch(err => {
            res.status(500).json({
                success: false,
                message: "Sunucu hatası"
            });
        })
    } else {
        team.findOneAndUpdate({ userId: userId }, {
            $set: {
                releventField: relevantField,
                website,
                exprerience: selectedOptions
            }
        }, { upsert: true })
        .then(x => {
            res.status(200).json({
                success: true,
                team: x
            })
        }).catch(err => {
            res.status(500).json({
                success: false,
                message: "Sunucu hatası"
            });
        })
    }
});


app.get('/pricing', async (req, res) => {
    const { authorization } = req.headers;
    const token = authorization.split(" ")[1];

    const session = await checkSession(res, token);
    if (!session) return;
    let userData = await user.findOne({ userId: session.userId });
    if (!userData) return res.status(404).json({ success: false, message: "Kullanıcı bulunamadı." });
    if (userData.permission != "Admin") return res.status(404).json({ success: false, message: "Kullanıcı bulunamadı." });
    
    const pricingSetup = {
        planTitles: [
          {
            id: 1,
            title: "Bronz",
            price: "400",
          },
          {
            id: 2,
            title: "Silver",
            price: "500",
          },
          {
            id: 3,
            title: "Gold",
            price: "700",
          },
        ],
    
        planFeatures: [
          {
            id: 1,
            name: "Web Yönetimi",
            value: [false, false, true],
          },
          {
            id: 2,
            name: "Sesli Karşılama Botları",
            value: [false, true, true],
          },
          {
            id: 3,
            name: "Yapay Zeka Sistemleri",
            value: [false, false, true],
          },
          {
            id: 4,
            name: "Otomatik Yetki Sistemi",
            value: [false, true, true],
          },
          {
            id: 5,
            name: "Event Bot",
            value: [false, false, true],
          },
          {
            id: 6,
            name: "7/24 Destek",
            value: [true, true, true],
          },
        ],
      };

    res.status(200).json({ success: true, pricing: pricingSetup });
})


app.get('/get-roles', async (req, res) => {
    const { authorization } = req.headers;
    const token = authorization.split(" ")[1];
    const session = await checkSession(res, token);
    if (!session) return;
    const userData = await user.findOne({ userId: session.userId });
    let setupData = await setup.findOne({ serverID: userData.guildId });
    if (!userData) return res.status(404).json({ success: false, message: "Kullanıcı bulunamadı." });
    const guildData = client.guilds.cache.find(x => x.id == userData.guildId);
    if (!guildData) return res.status(404).json({ success: false, message: "Sunucu bulunamadı." });
    if (!setupData) setupData = [];
    const roles = guildData.roles.cache;
    try {
        res.status(200).json({ success: true, guildData: roles, dbGuildData: setupData });
    } catch (error) {
        console.log(error);
        res.status(500).json({ success: false, message: "Sunucu hatası" });
    }
});

app.get('/get-channels', async (req, res) => {
    const { authorization } = req.headers;
    const token = authorization.split(" ")[1];
    const session = await checkSession(res, token);
    if (!session) return;
    const userData = await user.findOne({ userId: session.userId });
    let setupData = await setup.findOne({ serverID: userData.guildId });
    if (!userData) return res.status(404).json({ success: false, message: "Kullanıcı bulunamadı." });
    const guildData = client.guilds.cache.find(x => x.id == userData.guildId);
    if (!guildData) return res.status(404).json({ success: false, message: "Sunucu bulunamadı." });
    if (!setupData) setupData = [];
    const roles = guildData.channels.cache;
    return res.status(200).json({ success: true, guildData: roles, dbGuildData: setupData });
});


app.get('/get-user', async (req, res) => {
    const { authorization } = req.headers;
    const token = authorization.split(" ")[1];

    const session = await checkSession(res, token);
    if (!session) return;
    let userData = await user.findOne({ userId: session.userId });
    if (!userData) return res.status(404).json({ success: false, message: "Kullanıcı bulunamadı." });
    const memberData = client.guilds.cache.get(userData.guildId).members.cache.get(userData.userId);
    if (!memberData) return res.status(404).json({ success: false, message: "Üye bulunamadı." });
    userData = userData.toObject();
    userData["memberData"] = memberData;
    try {
        res.status(200).json({ success: true, userData });
    } catch (err) {
        console.log(err.message)
        res.status(500).json({ success: false, message: "Sunucu hatası" });
    }
});


app.get('/get-guild', async (req, res) => {
    const { authorization } = req.headers;
    const token = authorization.split(" ")[1];

    const session = await checkSession(res, token);
    if (!session) return;
    const userData = await user.findOne({ userId: session.userId });
    if (!userData) return res.status(404).json({ success: false, message: "Kullanıcı bulunamadı." });
    const setupData = await setup.findOne({ serverID: userData.guildId });
    const guildData = client.guilds.cache.get(userData.guildId);
    const guildStatistics = await webGuildStatistics.findOne({ guildId: userData.guildId });
    const otherDatas = {};
    if (!guildStatistics) {
        const guildStat = new webGuildStatistics({
            guildId: guildData.id,
            guildBoostCount: guildData.premiumSubscriptionCount,
            guildMemberCount: guildData.memberCount,
            guildTagCount: setupData ? guildData.members.cache.filter(x => x.user.username.includes(setupData.serverTag)).size : null,
            guildVoiceCount: guildData.members.cache.filter(x => x.voice.channel).size
        });

        await guildStat.save()
            .then(data => {
                otherDatas["statBoostCount"] = data.guildBoostCount;
                otherDatas["statMemberCount"] = data.guildMemberCount;
                otherDatas["statTagCount"] = data.guildTagCount;
                otherDatas["statVoiceCount"] = data.guildVoiceCount;
                otherDatas["latestUpdate"] = data.latestUpdate;
            })
            .catch(e => {
                console.log(e);
                res.status(500).json({ success: false, message: "Sunucu hatası" });
            });
        // else if latestUpdate was updated 7 days ago, reset and save the newest data. 
    } else if (guildStatistics.latestUpdate) {
        const date = new Date(guildStatistics.latestUpdate);
        const now = new Date();
        const diffTime = Math.abs(now - date);
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
        if (diffDays >= 7) {
            guildStatistics.guildBoostCount = guildData.premiumSubscriptionCount;
            guildStatistics.guildMemberCount = guildData.memberCount;
            guildStatistics.guildTagCount = setupData ? guildData.members.cache.filter(x => x.user.username.includes(setupData.serverTag)).size : null;
            guildStatistics.guildVoiceCount = guildData.members.cache.filter(x => x.voice.channel).size;
            guildStatistics.latestUpdate = Date.now();
            await guildStatistics.save()
                .then(data => {
                    otherDatas["statBoostCount"] = data.guildBoostCount;
                    otherDatas["statMemberCount"] = data.guildMemberCount;
                    otherDatas["statTagCount"] = data.guildTagCount;
                    otherDatas["statVoiceCount"] = data.guildVoiceCount;
                    otherDatas["latestUpdate"] = data.latestUpdate;
                })
                .catch(e => {
                    console.log(e);
                    res.status(500).json({ success: false, message: "Sunucu hatası" });
                });
        } else {
            otherDatas["statBoostCount"] = guildStatistics.guildBoostCount;
            otherDatas["statMemberCount"] = guildStatistics.guildMemberCount;
            otherDatas["statTagCount"] = guildStatistics.guildTagCount;
            otherDatas["statVoiceCount"] = guildStatistics.guildVoiceCount;
            otherDatas["latestUpdate"] = guildStatistics.latestUpdate;
        }
    } else {
        otherDatas["statBoostCount"] = guildStatistics.guildBoostCount;
        otherDatas["statMemberCount"] = guildStatistics.guildMemberCount;
        otherDatas["statTagCount"] = guildStatistics.guildTagCount;
        otherDatas["statVoiceCount"] = guildStatistics.guildVoiceCount;
        otherDatas["latestUpdate"] = guildStatistics.latestUpdate;
    }

    otherDatas["boostCount"] = guildData.premiumSubscriptionCount;
    otherDatas["memberCount"] = guildData.memberCount;
    otherDatas["tagCount"] = setupData ? guildData.members.cache.filter(x => x.user.username.includes(setupData.serverTag)).size : null;
    otherDatas["voiceCount"] = guildData.members.cache.filter(x => x.voice.channel).size;
    otherDatas["onlineCount"] = guildData.members.cache.filter(x => x.presence && x.presence.status).size;


    if (!guildData) return res.status(404).json({ success: false, message: "Sunucu bulunamadı.", matter: "guildNotFound" });
    if (!setupData) return res.status(404).json({ success: false, message: "Sunucu ayarları bulunamadı.", matter: "setupNotFound", guildData, otherDatas });
    otherDatas["taggedData"] = guildData.members.cache.filter(x => x.roles.cache.has(setupData.familyRole)).size;
    console.log(guildData.members.cache.filter(x => x.roles.cache.has(setupData.familyRole)));
    return res.status(200).json({ success: true, setupData, guildData, otherDatas });
});

app.get('/get-audit-logs', async (req, res) => {
    // user silindiğinde session silinecek mi ?
    const { authorization } = req.headers;
    const token = authorization.split(" ")[1];
    const session = await checkSession(res, token);
    if (!session) return;
    const userData = await user.findOne({ userId: session.userId });
    if (!userData) return res.status(404).json({ success: false, message: "Kullanıcı bulunamadı." });
    await client.guilds.cache.get(userData.guildId).fetchAuditLogs({})
        .then(data => {
            const auditData = [];
            const sevenDaysAgo = new Date();
            sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
            const auditActionNames = [
                { type: AuditLogEvent.ChannelCreate, name: "Kanal Oluşturdu" },
                { type: AuditLogEvent.ChannelDelete, name: "Kanal Sildi" },
                { type: AuditLogEvent.ChannelUpdate, name: "Kanal Güncelledi" },
                { type: AuditLogEvent.RoleCreate, name: "Rol Oluşturdu" },
                { type: AuditLogEvent.RoleDelete, name: "Rol Sildi" },
                { type: AuditLogEvent.RoleUpdate, name: "Rol Güncelledi" },
                { type: AuditLogEvent.GuildUpdate, name: "Sunucu Güncelledi" },
                { type: AuditLogEvent.MemberBanAdd, name: "Üye Banladı" },
                { type: AuditLogEvent.MemberBanRemove, name: "Üye Banladı" },
                { type: AuditLogEvent.MemberKick, name: "Üye Kickledi" },
                { type: AuditLogEvent.MemberPrune, name: "Üye Kickledi" }
            ];
            data = data.entries.filter(x => auditActionNames.find(an => an.type == x.action) && new Date(x.createdAt) > sevenDaysAgo);
            data.forEach(d => {
                auditData.push({
                    executor: client.users.cache.get(d.executorId),
                    target: client.users.cache.get(d.targetId),
                    action: auditActionNames.find(x => x.type == d.action).name,
                    createdAt: d.createdAt
                });
            })
            res.status(200).json({ success: true, auditLogsData: auditData });
        })
        .catch(e => {
            console.log(e);
            res.status(500).json({ success: false, message: "Sunucu hatası" });
        });
});


app.get('/chat/:id', async (req, res) => {
    const { authorization } = req.headers;
    const token = authorization.split(" ")[1];
    const chatId = req.params.id;
    const session = checkSession(res, token);
    if (!session) return;
    const userData = user.findOne({ userId: session.userId });
    if (!userData) return res.status(404).json({ success: false, message: "Kullanıcı bulunamadı." });
    const chatData = await chat.findOne({ userId: session.userId, supportId: chatId });
    if (!chatData) return res.status(404).json({ success: false, message: "Mesaj bulunamadı." });
    res.status(200).json({ success: true, chatData })
});


async function generateMsg(text, history = []) {
    const genAI = new GoogleGenerativeAI(config.AI_KEY);
    const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });
    const fineTuneText = `
        Merhaba, sitem üzerinden bir yapay zeka entegrasyonu yapıyorum ve sen o yapay zekasın. 
        Sadece benim izin verdiğim şeylere cevap vermelisin, onun dışındaki her şeye 
        'Üzgünüm, bunu yanıtlamak için programlanmadım.' gibi olumsuz bir geri dönüş yapmalısın.
        Bu mesajı aldıysan, yapay zekanın çalıştığını ve benimle iletişim kurabileceğini anlamalısın.

        İşte örnek birkaç cümle:
        ben: "Web üzerinde profilim kısımına neden giremiyorum?"
        yapay zeka: "Merhaba, web sitemiz üzerinde 'Profilim' kısmına giremeyişinizin sebebi geçici olarak bakımda olması olabilir."

        ben: "Sunucu profiline nasıl erişebilirim?"
        yapay zeka: "Sunucu profiline erişmek için web sitemiz içerisindeki 'Dashboard' kısmına tıklayarak sunucu profiline erişebilirsiniz."

        ben: "Kurulumları nasıl yapabilirim?"
        yapay zeka: "Kurulumlarınızı yapabilmek için web sitemiz üzerindeki 'Setup' veya 'Guard' kısmına tıklayarak kurulumlarınızı yapabilirsiniz."

        ben: "10+19" kaç eder?
        yapay zeka: "Üzgünüm, matematik ve cebir sorularını yanıtlamak için değil, CELX STORE'da sizlere site üzerinde yardımcı olmak amaçlı Yapay Zeka asistanı olarak programlandım."

        ben: "Merhaba, benim adım Ahmet."
        yapay zeka: "Merhaba Ahmet, ben CELX Web Asistan, memnun oldum. Bugün nasıl yardımcı olabilirim?"
        
        ben: "Selam, ben Can."
        yapay zeka: "Merhaba Can, ben CELX Web Asistan, memnun oldum. Bugün nasıl yardımcı olabilirim?"

        ben: "Bana bir şaka anlatır mısın?"
        yapay zeka: "Üzgünüm, şaka anlatmak için programlanmadım."

        ben: "Bana bir hikaye anlatır mısın?"
        yapay zeka: "Üzgünüm, hikaye anlatmak için programlanmadım."

        ben: "Bir şarkı söyler misin?"
        yapay zeka: "Üzgünüm, şarkı söylemek için programlanmadım."

        --SORU BAŞLANGIÇ-- ile başlayan ve 
        --SORU SON-- ile biten cümleler arasındaki metinleri yanıtlamalısın.
        Bu şekilde benimle iletişim kurabilirsin.
    `
    const aiChat = model.startChat({
        history: [
            {
                role: "user",
                parts: [{ text: fineTuneText }]
            },
            {
                role: "model",
                parts: [{ text: "Tamamdır!" }]
            }
        ],
    });
    let result = await aiChat.sendMessage(
        `
            --SORU BAŞLANGIÇ--
            ${text}
            --SORU SON--
        `
    );
    console.log(result.response.text());
    return result.response.text()
}


app.get('/all-support', async (req, res) => {
    const { authorization } = req.headers;
    const token = authorization.split(" ")[1];
    const session = checkSession(res, token);
    if (!session) return;
    const userData = user.findOne({ userId: session.userId });
    if (!userData) return res.status(404).json({ success: false, message: "Kullanıcı bulunamadı." });
    const supData = await chat.find({ userId: session.userId });
    if (!supData) return res.status(404).json({ success: false, message: "Destek bulunamadı." });
    res.status(200).json({ success: true, supData });
});

app.post('/support', async (req, res) => {
    const { authorization } = req.headers;
    const token = authorization.split(" ")[1];
    const { supportId, title, message } = req.body;
    const session = checkSession(res, token);
    if (!session) return;
    const userData = await user.findOne({ userId: session.userId });
    if (!userData) return res.status(404).json({ success: false, message: "Kullanıcı bulunamadı." });
    const chatData = await chat.findOne({ userId: session.userId, supportId: supportId });
    const logChannel = client.channels.cache.find(c => c.id == config.logChannelId);
    const guildUser = client.users.cache.get(userData.userId);
    const userId = userData.userId;
    const embed = new EmbedBuilder()
        .setAuthor({ name: `Web'den Destek İsteği!` })
        .setColor(Colors.LuminousVividPink)
        .setFooter({ text: "Developed by Cranedevs." })
    if (!chatData) {
        const msg = await generateMsg(message)

        const newChat = new chat({
            userId: userId,
            supportId: supportId,
            title: title,
            messages: [
                {
                    message: message,
                    sender: userId,
                    createdAt: Date.now(),
                    role: "user"
                },
                {
                    message: msg,
                    sender: "CELX ADES",
                    createdAt: Date.now(),
                    role: "model"
                }
            ]
        });

        newChat.save()
            .then(data => {
                res.status(200).json({ success: true, message: "Mesaj başarıyla gönderildi!", data });
                embed.addFields([
                    {
                        name: `${guildUser?.username || session.userId || "Bulunamadı."}`,
                        value: `\`\`\`fix\n${message}\`\`\``,
                        inline: true
                    },
                    {
                        name: "Yapay Zeka",
                        value: `\`\`\`fix\n${msg}\`\`\``,
                        inline: true
                    }
                ])
                logChannel.send({ embeds: [embed] });
            })
            .catch(e => {
                console.log(e);
                res.status(500).json({ success: false, message: "Sunucu hatası" });
            });
    } else {
        const msg = await generateMsg(message, chatData.messages);

        const conservation = {
            messages: {
                message: message,
                sender: userData.userId,
                createdAt: Date.now(),
                role: "user"
            },
            messages: {
                message: msg,
                sender: "CELX ADES",
                createdAt: Date.now(),
                role: "model"
            }
        }

        for (let index = 0; index < Object.keys(conservation).length; index++) {
            const element = Object.keys(conservation)[index];
            await chat.findOneAndUpdate({ userId: session.userId, supportId: supportId }, {
                $push: {
                    messages: conservation[element]
                }
            }, { upsert: true })
                .catch(e => {
                    console.log(e);
                    res.status(500).json({ success: false, message: "Sunucu hatası" });
                });
        }

        embed.addFields([
            {
                name: `${guildUser?.username || session.userId || "Bulunamadı."}`,
                value: `\`\`\`fix\n${message}\`\`\``,
                inline: true
            },
            {
                name: "Yapay Zeka",
                value: `\`\`\`fix\n${msg}\`\`\``,
                inline: true
            }
        ])
        logChannel.send({ embeds: [embed] });
        const newChatData = await chat.findOne({ userId: session.userId, supportId: supportId });
        res.status(200).json({ success: true, message: "Mesaj başarıyla gönderildi!", data: newChatData });
    }
});


app.get("/get-whitelist", async (req, res) => {
    const { authorization } = req.headers;
    const token = authorization.split(" ")[1];
    const session = await checkSession(res, token);
    if (!session) return;
    const userData = await user.findOne({ userId: session.userId });
    if (!userData) return res.status(404).json({ success: false, message: "Kullanıcı bulunamadı." });
    const whitelistData = await whitelist.find({ guildID: userData.guildId });
    if (!whitelistData) return res.status(404).json({ success: false, message: "Güvenli liste bulunamadı." });
    const whitelistMembersData = [];
    for (let i = 0; i < whitelistData.length; i++) {
        const member = client.guilds.cache.get(userData.guildId).members.cache.find(m => m.id === whitelistData[i].user);
        if (member) {
            whitelistMembersData.push({
                member: member,
                whitelistData: whitelistData[i]
            });
        }
    }
    return res.status(200).json({ success: true, whitelistMembersData });
});


app.post('/delete-whitelist', async (req, res) => {
    const { userId } = req.body;
    const { authorization } = req.headers;
    const token = authorization.split(" ")[1];
    const session = await checkSession(res, token);
    if (!session) return;
    const userData = await user.findOne({ userId: session.userId });
    if (!userData) return res.status(404).json({ success: false, message: "Kullanıcı bulunamadı." });
    const findMember = client.guilds.cache.get(userData.guildId).members.cache.find(m => m.id === userId);
    if (!findMember) return res.status(404).json({ success: false, message: "Belirtilen üye sunucuda bulunamadı." });

    await whitelist.findOneAndDelete({ guildID: userData.guildId, user: userId })
        .then(data => {
            res.status(200).json({ success: true, message: "Üye başarıyla güvenli listeden çıkarıldı!", data });
        })
        .catch(e => {
            console.log(e);
            res.status(500).json({ success: false, message: "Sunucu hatası" });
        });
});

app.post('/update-whitelist', async (req, res) => {
    const { userId, type, maker } = req.body;
    const { authorization } = req.headers;
    const token = authorization.split(" ")[1];
    const session = await checkSession(res, token);
    if (!session) return;
    const userData = await user.findOne({ userId: session.userId });
    if (!userData) return res.status(404).json({ success: false, message: "Kullanıcı bulunamadı." });
    const findMember = client.guilds.cache.get(userData.guildId).members.cache.find(m => m.id === userId);
    if (!findMember) return res.status(404).json({ success: false, message: "Belirtilen üye sunucuda bulunamadı." });

    await whitelist.findOneAndUpdate({ guildID: userData.guildId, user: userId }, {
        type: type,
        maker: maker
    }, { upsert: true })
        .then(data => {
            res.status(200).json({ success: true, message: "Üyenin güvenlik tipi başarıyla güncellendi!", data });
        })
        .catch(e => {
            console.log(e);
            res.status(500).json({ success: false, message: "Sunucu hatası" });
        });
});

app.get('/get-points', async (req, res) => {
    const { authorization } = req.headers;
    const token = authorization.split(" ")[1];
    const session = await checkSession(res, token);
    if (!session) return;
    const userData = await user.findOne({ userId: session.userId });
    if (!userData) return res.status(404).json({ success: false, message: "Kullanıcı bulunamadı." });

    const data = await gpoint.find({ guildID: userData.guildId });
    if (!data) return res.status(404).json({ success: false, message: "Puan bulunamadı." });
    const guild = client.guilds.cache.get(userData.guildId);

    const editedPointData = data.map(d => {
        return {
            ROLE: guild.roles.cache.get(d.ROLE),
            POINT: d.POINT,
            EXTRA_ROLE: d.EXTRA_ROLE.map(x => {
                return guild.roles.cache.get(x)
            })
        }
    })

    return res.status(200).json({ success: true, pointData: editedPointData });
})

app.post('/add-point', async (req, res, next) => {
    const { authorization } = req.headers;
    const token = authorization.split(" ")[1];
    const session = await checkSession(res, token);
    if (!session) return;
    const userData = await user.findOne({ userId: session.userId });
    if (!userData) return res.status(404).json({ success: false, message: "Kullanıcı bulunamadı." });
    let keys = [];
    for (const key in req.body) {
        keys.push({ key, value: req.body[key] });
    }
    let gorevPuan = {};
    keys.forEach(async k => {
        const { key, value } = k;
        if (key.startsWith("gorevp")) {
            const newKey = key.replace("gorevp", "").replace("-", "_").toUpperCase();
            const newValue = value;
            if (newKey == "POINT") {
                gorevPuan[newKey] = parseInt(newValue);
            } else {
                gorevPuan[newKey] = newValue;
            }
        }
    });
    const data = await gpoint.find({});
    gorevPuan["POSITION"] = data.length + 1;
    // console.loggorevPuan);
    const newTask = new gpoint({ guildID: userData.guildId, ...gorevPuan });
    // set the _id 
    newTask.save()
        .then(data => {
            res.status(200).json({ success: true, message: "Görev başarıyla eklendi!", data });
        })
        .catch(x => {
            console.error(x);
            res.status(500).send('Internal Server Error');
        });
});

app.get('/get-duties', async (req, res) => {
    const { authorization } = req.headers;
    const token = authorization.split(" ")[1];
    const session = await checkSession(res, token);
    if (!session) return;
    const userData = await user.findOne({ userId: session.userId });
    if (!userData) return res.status(404).json({ success: false, message: "Kullanıcı bulunamadı." });
    const guild = client.guilds.cache.get(userData.guildId);
    const dutyData = await gEkle.find({ guildID: userData.guildId });
    if (!dutyData) return res.status(404).json({ success: false, message: "Görev bulunamadı." });
    const editedDutyData = dutyData.map(d => {
        return {
            ROLE: guild.roles.cache.get(d.ROLE),
            DAY: d.DAY,
            REQUIRED_TASKS: d.REQUIRED_TASKS,
            EXTRA_ROLE: d.EXTRA_ROLE.map(x => {
                return guild.roles.cache.get(x)
            })
        }
    })
    return res.status(200).json({ success: true, dutyData: editedDutyData });
});

app.post('/update-guard-settings', async (req, res) => {
    const { type, process, serverId } = req.body;
    const { authorization } = req.headers;
    const token = authorization.split(" ")[1];
    const session = await checkSession(res, token);
    if (!session) return;
    const userData = await user.findOne({ userId: session.userId });
    if (!userData) return res.status(404).json({ success: false, message: "Kullanıcı bulunamadı." });
    const guardData = await guard.findOne({ serverId: userData.guildId });

    if (!guardData || (guardData && !guardData.type)) {
        const newGuard = new guard({
            serverId: userData.guildId,
            type: type,
            action: process
        })
        newGuard.save()
            .then(data => {
                res.status(200).json({ success: true, message: "Koruma başarıyla güncellendi!", data });
            })
            .catch(e => {
                console.log(e);
                res.status(500).json({ success: false, message: "Sunucu hatası" });
            });
    } else {
        await guard.findOneAndUpdate({ serverId: userData.guildId, type: type }, {
            action: process
        }, { upsert: true })
            .then(data => {
                res.status(200).json({ success: true, message: "Koruma başarıyla güncellendi!", data });
            })
            .catch(e => {
                console.log(e);
                res.status(500).json({ success: false, message: "Sunucu hatası" });
            });
    }


})

app.get('/get-guard-settings', async (req, res) => {
    const { authorization } = req.headers;
    const token = authorization.split(" ")[1];
    const session = await checkSession(res, token);
    console.log("geld")
    if (!session) return;
    const userData = await user.findOne({ userId: session.userId });
    if (!userData) return res.status(404).json({ success: false, message: "Kullanıcı bulunamadı." });
    const guardData = await guard.find({ serverId: userData.guildId });
    if (!guardData) return res.status(404).json({ success: false, message: "Koruma ayarları bulunamadı." });
    return res.status(200).json({ success: true, guardData });
});


app.post('/add-duty', async (req, res, next) => {
    const { authorization } = req.headers;
    const token = authorization.split(" ")[1];
    const session = await checkSession(res, token);
    const { goreverole } = req.body;
    console.log(req.body);
    if (!session) return;
    const userData = await user.findOne({ userId: session.userId });
    if (!userData) return res.status(404).json({ success: false, message: "Kullanıcı bulunamadı." });
    const gorevData = await gEkle.find({ guildID: userData.guildId })
    let keys = [];
    for (const key in req.body) {
        keys.push({ key, value: req.body[key] });
    }
    let gorevEkle = {};
    let requiredTasks = [];
    keys.forEach(k => {
        const { key, value } = k;
        const newKey = key.replace("goreve", "").replace("-", "_").toUpperCase();
        const newValue = req.body[key];
        ge = 1;
        if (newKey == "PUBLIC" || newKey == "STREAMER" || newKey == "AFK") {
            const name = `${newKey.replace("PUBLIC", "Public").replace("STREAMER", "Streamer")} Kanallarda Vakit Geçir`;
            requiredTasks.push({ TYPE: newKey, NAME: name, COUNT: `${newValue}h`, COUNT_TYPE: "TIME" });
        } else if (newKey == "MESSAGE") {
            const name = "Chat Kanalında Mesaj At";
            requiredTasks.push({ TYPE: newKey, NAME: name, COUNT: parseInt(newValue), COUNT_TYPE: "CLASSIC" });
        } else if (newKey == "DAY") {
            gorevEkle[newKey] = parseInt(value);
        } else {
            gorevEkle[newKey] = value;
        }
    });

    if (gorevData && gorevData.find(x => x.ROLE == goreverole)) {
        await gEkle.findOneAndUpdate({ guildID: userData.guildId, ROLE: goreverole }, {
            $set: {
                ...gorevEkle,
                "REQUIRED_TASKS": requiredTasks,
            }
        }, { upsert: true })
            .then(dutyData => {
                res.status(200).json({ success: true, message: "Görev başarıyla güncellendi!", dutyData });
                return;
            })
            .catch(x => {
                console.error(x);
                res.status(500).send('Internal Server Error');
                return;
            });
    } else {
        const newDuty = new gEkle({
            ...gorevEkle,
            guildID: userData.guildId,
            "REQUIRED_TASKS": requiredTasks,
        })

        newDuty.save()
            .then(dutyData => {
                res.status(200).json({ success: true, message: "Görev başarıyla eklendi!", dutyData });
            })
            .catch(x => {
                console.error(x);
                res.status(500).send('Internal Server Error');
            });
    }
});

app.post('/add-whitelist', async (req, res) => {
    const { userId, type, totalLimit, maker } = req.body;
    const { authorization } = req.headers;
    const token = authorization.split(" ")[1];
    const session = await checkSession(res, token);
    if (!session) return;
    const userData = await user.findOne({ userId: session.userId });
    if (!userData) return res.status(404).json({ success: false, message: "Kullanıcı bulunamadı." });
    const findMember = client.guilds.cache.get(userData.guildId).members.cache.find(m => m.id === userId);
    if (!findMember) return res.status(404).json({ success: false, message: "Belirtilen üye sunucuda bulunamadı." });

    const newWhitelist = new whitelist({
        guildID: userData.guildId,
        user: userId,
        type: type,
        totalLimit: totalLimit,
        maker: maker
    })

    newWhitelist.save()
        .then(data => {
            res.status(200).json({ success: true, message: "Üye başarıyla güvenli listeye eklendi!", data });
        })
        .catch(e => {
            console.log(e);
            res.status(500).json({ success: false, message: "Sunucu hatası" });
        });
});

app.post("/login", async (req, res) => {
    const { email, password } = req.body;

    const userDoc = await user.findOne({ email: email });


    if (!userDoc) return res.status(404).json({ success: false, message: "Kullanıcı bulunamadı" });
    if (userDoc.password !== password) return res.status(401).json({ success: false, message: "Hatalı şifre" });

    const newToken = await generateToken(11);
    await sessions.findOneAndUpdate({ token: newToken }, {
        userId: userDoc.userId,
        expires: Date.now() + 1000 * 60 * 60 * 24
    }, { upsert: true })
        .catch(e => {
            console.log(e);
            res.status(500).json({ success: false, message: "Sunucu hatası" });
        });

    return res.status(200).json({ success: true, message: "Başarıyla giriş yapıldı", redirect: 'dashboard', token: newToken });
});


app.post('/setup', async (req, res) => {
    const body = req.body;
    const { authorization } = req.headers;
    const token = authorization.split(" ")[1];
    const session = await checkSession(res, token);
    if (!session) return;
    const userData = await user.findOne({ userId: session.userId });
    if (!userData) return res.status(404).json({ success: false, message: "Kullanıcı bulunamadı." });

    let savedDataLength = 0;
    let keys = [];
    for (const key in req.body) {
        keys.push({ key, value: req.body[key] });
    }
    keys = keys.filter(x => x.value != '' && x.value != 'Lütfen Seçiniz');
    keys.forEach(async k => {
        const { key, value } = k;
        setup.findOneAndUpdate({ serverID: userData.guildId }, {
            $set: {
                [key]: value
            }
        }, { upsert: true })
        .then(data => {
            res.status(200).json({ success: true, message: "Değişiklikler başarıyla kaydedildi!", data })
        })
        .catch(e => {
            res.status(500).json({ success: false, message: "Sunucu hatası." })
        })
    });


});


function generateToken(len) {
    let chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    let token = "";
    for (let i = 0; i < len; i++) {
        token += chars[Math.floor(Math.random() * chars.length)];
    }
    return token;
}

client.login(config.token);
app.listen(PORT, () => {
    console.log(`Sunucu ${PORT} portunda başlatıldı`);
});

