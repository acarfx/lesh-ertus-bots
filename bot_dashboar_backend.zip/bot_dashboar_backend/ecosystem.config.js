let crane = [
    {
      name: "Backend",
      namespace: "CraneDevs",
      script: 'index.js',
      watch: false,
      exec_mode: "cluster",
      max_memory_restart: "2G",
      cwd: "./"
    },
];

module.exports = {apps: crane}