const { Schema, model } = require("mongoose");


const userSchema = new Schema({
    customerId: { type: String, default: null },
    currentPlan: { type: String, default: null },
    userId: { type: String, default: null },
    password: { type: String, default: null },
    email: { type: String, default: null },
    guildId: { type: String, default: null },
    permission: { type: String, default: null },
    phone: { type: String, default: null },
    isTwoFactorEnabled: { type: Boolean, default: false },
    twoFactorSecret: { type: String, default: null },
    twoFactorRecovery: { type: String, default: null }, 
});

module.exports = model("users", userSchema);