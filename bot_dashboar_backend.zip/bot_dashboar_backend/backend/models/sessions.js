const { Schema, model } = require("mongoose");


const userSchema = new Schema({
    userId: { type: String, default: "" },
    token:  { type: String, default: "" },
    expires:{ type: Date, default: Date.now() }
});

module.exports = model("sessions", userSchema);