const express = require("express");
const route = express.Router();
const path = require("path");
const user = require("../models/user");


route.get("/", (req, res) => {
    res.send("fdsfsdf");
});

route.post("/", async (req, res) => {
    const { email, password } = req.body;

    const userDoc = await user.findOne({ email: email });

    if (!userDoc) return res.status(400).json({ success: false, message: "Kullanıcı bulunamadı" });
    if (userDoc.password !== password) return res.status(400).json({ success: false, message: "Hatalı şifre" });
    return res.status(200).json({ success: true, message: "Başarıyla giriş yapıldı", data: userDoc });
});


module.exports = route;