const express = require("express");
const app = express();
const path = require("path");
const mongoose = require("mongoose");
const config = require("./config.json")
const cors = require("cors");
const { Client, GatewayIntentBits, Partials, Events } = require("discord.js");

const PORT = 3001;

const client = new Client({
    intents: Object.keys(GatewayIntentBits),
    partials: Object.keys(Partials)
});


client.on(Events.ClientReady, async ()  => {
    console.log("Bot başarıyla başlatıldı");
});

const login = require("./routes/login");
const sessions = require("./models/sessions");
const user = require("./models/user");
const setup = require("./models/setup");

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

/* enable cors */
app.use(
    cors({
        origin: "*",
        methods: ["GET", "POST"],
        allowedHeaders: ["Content-Type", "Authorization"]
    })
);


mongoose.connect(config.mongoURL, {
    useNewUrlParser: true,
    useUnifiedTopology: true
}).then(() => {
    console.log("MongoDB'ye bağlanıldı");
}).catch((err) => {
    console.log("MongoDB'ye bağlanırken hata oluştu: " + err);
});

app.use(express.json());
app.use(express.urlencoded({ extended: false }));


app.get("/guild-data", async (req, res) => {
    const { token } = req.query;
    const session = await sessions.findOne({ token });

    if (!session) return res.status(404).json({ success: false, message: "Oturum bulunamadı, tekrar giriş yapın" });
    if(session.expires >= Date.now()) {
        await sessions.findOneAndDelete({ token })
        .catch(e => { 
            console.log(e);
            res.status(500).json({ success: false, message: "Sunucu hatası" });
        });
        return res.status(401).json({ success: false, message: "Oturum süresi doldu, tekrar giriş yapın" });
    }
    
    const user = await user.findOne({ userId: session.userId });
    if (!user) return res.status(404).json({ success: false, message: "Kullanıcı bulunamadı." });
    const guildCacheData = client.guilds.cache.get(user.guildId);
    const guildDatabase = await setup.findOne({ serverID: user.guildId });
    if(!guildCacheData) return res.status(404).json({ success: false, message: "Sunucu bilgileri yüklenemedi." }); 
    if(!guildDatabase) return res.status(404).json({ success: false, message: "Sunucu bilgileri yüklenemedi." }); 

    res.status(200).json({ success: true, guildCacheData, guildDatabase });
});



app.post("/login", async (req, res) => {
    const { email, password } = req.body;

    console.log(email, password);
    const userDoc = await user.findOne({ email: email });

    console.log(userDoc);

    if (!userDoc) return res.status(404).json({ success: false, message: "Kullanıcı bulunamadı" });
    if (userDoc.password !== password) return res.status(401).json({ success: false, message: "Hatalı şifre" });
    
    const newToken = generateToken(11);
    await sessions.findOneAndUpdate({ token: newToken }, {
        userId: userDoc.userId,
        expires: Date.now() + 1000 * 60 * 60 * 24
    }, { upsert: true})
    .catch(e => { 
        console.log(e);
        res.status(500).json({ success: false, message: "Sunucu hatası" });
    });

    return res.status(200).json({ success: true, message: "Başarıyla giriş yapıldı", redirect: 'dashboard', token: newToken });
});

function generateToken(len) {
    let chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    let token = "";
    for (let i = 0; i < len; i++) {
        token += chars[Math.floor(Math.random() * chars.length)];
    }
}

app.listen(PORT, () => {
  console.log(`Sunucu ${PORT} portunda başlatıldı`);
});

